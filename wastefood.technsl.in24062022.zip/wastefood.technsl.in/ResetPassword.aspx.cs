﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;

public partial class ResetPassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["email"] != null)
            {
                Response.Redirect("Home.aspx");
            }
        }

        if (con.State == ConnectionState.Closed)
            con.Open();
        string resetpassword_otp = Request.QueryString["resetpassword_otp"].ToString();
        string email = Request.QueryString["email"].ToString();


        string cmds = "select user_id from [userinfo] where email ='" + email.ToString() + "' and resetpassword_otp = '" + resetpassword_otp.ToString() + "' and resetpassword_otp != '' and resetpassword_otp != 0";
        SqlCommand checkemail = new SqlCommand(cmds, con);
        SqlDataReader read = checkemail.ExecuteReader();
        if (!read.Read())
        {
            notvalid.Visible = false;
            lblErrorMsg.Text = "Reset Password link is expired. Please try with differnt reset password link.";
            lblErrorMsg.ForeColor = System.Drawing.Color.Red;

        }
        con.Close();
    }

    protected void ResetPWDButton_Click(object sender, EventArgs e)
    {
        string email = Request.QueryString["email"].ToString();
        string qr = "update [userinfo] set password='" + MyEncrypt(password.Text.ToString()) + "', resetpassword_otp='' where email='" + email.ToString() + "'";
        con.Open();
        SqlCommand cmd = new SqlCommand(qr, con);
        cmd.ExecuteNonQuery();
        lblErrorMsg.Text = "You reset your password successfully.";
        lblErrorMsg.ForeColor = System.Drawing.Color.Red;
        con.Close();

        //if you want to send email regarding successfull reset password then.
    }
    private string MyEncrypt(string returnText)
    {
        string EncryptionKey = "E6C69AC9CCE39";
        byte[] clearBytes = Encoding.Unicode.GetBytes(returnText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                returnText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return returnText;
    }
}