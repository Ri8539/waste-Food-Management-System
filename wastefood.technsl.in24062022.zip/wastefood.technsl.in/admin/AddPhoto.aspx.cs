﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_AddPhoto : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void addPhoto_Click(object sender, EventArgs e)
    {
        byte[] photosPhoto = FileUpload1.FileBytes;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        string insertCmd = "insert into [photos](photos_name,photos_detail,price,photo ) values(@photos_name,@photos_detail,@myprice, @photo)";
        SqlCommand insertUser = new SqlCommand(insertCmd, con);
        insertUser.Parameters.AddWithValue("@photos_name", photos_name.Text);
        insertUser.Parameters.AddWithValue("@photos_detail", photos_detail.Text);
        insertUser.Parameters.AddWithValue("@myprice", price.Text);
        insertUser.Parameters.AddWithValue("@photo", photosPhoto);
        insertUser.ExecuteNonQuery();
        con.Close();
        Response.Redirect("Photos.aspx");
        //}
    }
}