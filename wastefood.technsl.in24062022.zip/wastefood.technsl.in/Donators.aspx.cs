﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

public partial class Donators : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conString"].ConnectionString);
    DataTable Cart_DataTable = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Bind();
        }

    }

    public void Bind()
    {
        Literal1.Text += "<div class='row'>";
        con.Open();
        SqlCommand cmd2 = new SqlCommand("select * from userinfo", con);
        SqlDataReader dr = cmd2.ExecuteReader();
        while (dr.Read())
        {
            Literal1.Text += "<div class='col-lg-4 col-md-6 special-grid drinks' style='' >";
            Literal1.Text += "<div class='gallery-single fix'>";
            Literal1.Text += "<img src = 'photoHandler.ashx?user_id=" + (int)dr["user_id"] + "' class='img-responsive' style='height:200px;' alt='Image'>";
            Literal1.Text += "<div class='why-text'>";
            //Literal1.Text += "<h4>" + (string)dr["photo"] + "</h4>";
            Literal1.Text += "<p>" + (string)dr["first_name"] + " " + (string)dr["last_name"] + "</p>";
            Literal1.Text += "</div>";
            Literal1.Text += "</div>";
            //Literal1.Text += "</div>";
        }
        con.Close();
        Literal1.Text += "</div>";
    }
}