﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;

public partial class LoginWithPassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["email"] != null)
            {
                Response.Redirect("Home.aspx");
            }
        }
    }

    protected void ConfirmLoginPasswordEmail_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        string cmds = "select email,password,first_name,last_name,user_id from [userinfo] where email ='" + email.Text.ToString() + "' and password = '" + MyEncrypt(password.Text.ToString()) + "'";
        SqlCommand checkemail = new SqlCommand(cmds, con);
        SqlDataReader read = checkemail.ExecuteReader();
        if (read.Read())
        {
            Session["email"] = read.GetValue(0).ToString().Trim();
            Session["first_name"] = read.GetValue(2).ToString().Trim();
            Session["last_name"] = read.GetValue(3).ToString().Trim();
            Session["user_id"] = read.GetValue(4).ToString().Trim();
            con.Close();
            Response.Redirect("Home.aspx");
        }
        else
        {
            lblErrorMsg.Text = "Invalid email and password";
            lblErrorMsg.ForeColor = System.Drawing.Color.Red;
            con.Close();
        }
    }

    private string MyEncrypt(string returnText)
    {
        string EncryptionKey = "E6C69AC9CCE39";
        byte[] clearBytes = Encoding.Unicode.GetBytes(returnText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                returnText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return returnText;
    }
}