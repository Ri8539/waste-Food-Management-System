﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;


public partial class ChangePassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["email"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }
    }

    protected void ChangePWDButton_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        string cmds = "select user_id from [userinfo] where password = @current_password";
        SqlCommand checkpwd = new SqlCommand(cmds, con);
        checkpwd.Parameters.AddWithValue("@current_password", MyEncrypt(old_password.Text.ToString()));
        SqlDataReader read = checkpwd.ExecuteReader();
        if (read.Read())
        {
            con.Close();
            string qr = "update [userinfo] set password='" + MyEncrypt(password.Text.ToString()) + "' where user_id=" + Session["user_id"];
            con.Open();
            SqlCommand cmd = new SqlCommand(qr, con);
            cmd.ExecuteNonQuery();
            lblErrorMsg.Text = "your password is changed successfully.";
            lblErrorMsg.ForeColor = System.Drawing.Color.Red;
            con.Close();

        }
        else
        {
            lblErrorMsg.Text = "Your old password is wrong.";
            lblErrorMsg.ForeColor = System.Drawing.Color.Red;
            con.Close();
        }
    }
    private string MyEncrypt(string returnText)
    {
        string EncryptionKey = "E6C69AC9CCE39";
        byte[] clearBytes = Encoding.Unicode.GetBytes(returnText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                returnText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return returnText;
    }
}