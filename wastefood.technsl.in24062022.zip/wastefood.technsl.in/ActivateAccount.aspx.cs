﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
public partial class ActvateAccount : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constring"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        //activation_code=" + activation_code + "&email=" + Base64Encode(email.Text.Trim())
        if (!IsPostBack)
        {
            if (Session["email"] != null)
            {
                Response.Redirect("Home.aspx");
            }
        }
        if (con.State == ConnectionState.Closed)
            con.Open();
        string activation_code = Request.QueryString["activation_code"].ToString();
        string email_ency = Request.QueryString["email"].ToString();

        string email = Base64Decode(email_ency.ToString());


        string cmds = "select user_id from [userinfo] where email ='" + email.ToString() + "' and activation_code = '" + activation_code.ToString() + "' and is_active =0";
        SqlCommand checkemail = new SqlCommand(cmds, con);
        SqlDataReader read = checkemail.ExecuteReader();
        if (read.Read())
        {
            con.Close();
            string qr = "update [userinfo] set is_active=1 where email='" + email.ToString() + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(qr, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("login.aspx");

        }
        else
        {
            lblErrorMsg.Text = "Activate account link is expired.";
            lblErrorMsg.ForeColor = System.Drawing.Color.Red;
        }
        con.Close();


    }
    public static string Base64Encode(string plainText)
    {
        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
        return System.Convert.ToBase64String(plainTextBytes);
    }
    public static string Base64Decode(string base64EncodedData)
    {
        var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
        return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
    }
}
